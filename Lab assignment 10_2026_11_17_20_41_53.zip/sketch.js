function setup() {
  createCanvas(400, 400);
  frameRate(60);
  strokeWeight(3);
}
function draw() {
  background(51);
  stroke(255, 212, 0);
  fill(255,65,0)
  animS.circle("c1", 50, 300, 100, 150);
  stroke(50, 50, 200);
  animS.line("l1", 60, 0, 350, 400, 350);
  stroke(0, 255, 255);
  fill(0,255,180)
  animS.rect("r1", 60, 80, 270, 100, 100);
  fill(255,65,0)
  stroke(50, 50, 200);
  animS.rect("r2", 60, 120, 320, 30, 50);
  stroke(50, 50, 200);
  fill(150, 50, 30);
  animS.triangle("t1", 60, 70, 270, 130, 200, 190, 270);
  stroke(50, 50, 200);
  fill(180, 230, 255);
  animS.square("w1", 40, 92, 285, 25);
  animS.square("w2", 40, 140, 285, 25); 
}
function mousePressed() {
  animS.reset();
}  