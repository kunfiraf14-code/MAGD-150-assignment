let goku;
let luffy;
let bear;

function preload() {
  goku = loadImage('goku.jpg');
  luffy = loadImage('luffy.jpg');
  bear = loadImage('bear.png');
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  image(goku, mouseX, mouseY, 190, 190);
  image(luffy, 200, 200, 190, 190);
  image(bear, mouseX + 230, mouseY + 150, 150, 150);

  fill('red');
  stroke(10);
  textFont('Courier New', 50);

  text('HAPPY WORLD!', 25, 40);
  text('BOOM!', 200, 70, 100, 70);
}


