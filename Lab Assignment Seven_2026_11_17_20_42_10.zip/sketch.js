function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES)
  print("Number of bolts: " + getBoltCount());
}

function draw() {
  background(220);
  for (let i = 0; i < getBoltCount(); i++) {
    lightning(i * 90, 150);
  }
}
  function getBoltCount() {
    return 4;
  }

function lightning(x,y) {
  push()
  translate(x,y)
  scale(0.5);
  rotate(-25)
  fill(255, 220, 0);
  noStroke();
  beginShape();
  vertex(0, 40);
  vertex(-30, 220);
  vertex(40, 220);
  vertex(10, 360);
  vertex(130, 170);
  vertex(60, 170);
  vertex(100, 40);
  endShape(CLOSE);
  pop();
}
  